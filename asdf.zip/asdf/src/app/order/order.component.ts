import { Component, OnInit } from '@angular/core';
import { PlacingService } from '../placing.service';
import { PlacingOrder } from '../PlacingOrder';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  placingorder:PlacingOrder;
  constructor(private placingService:PlacingService) { 
  //this.orderList= this.placingService.orderList;
   
  }
  
  ngOnInit() {
    this.show();
    
  }
  show()
  {
    this.placingService.show().subscribe(data=>(this.placingorder=data));
  }
  reload(){
    this.show();
  }

  flag=false;
  id;address;city;zipcode;price;dod

bo:PlacingOrder=new PlacingOrder;
  changeFlag(b:PlacingOrder){
    this.flag=true;
    this.id=b.id;;
    this.address=b.address;
    this.city=b.city;
    this.zipcode=b.zipcode;
    this.price=b.price;
    this.dod=b.dod;

  }
   update(data){
    let b:PlacingOrder=new PlacingOrder;
   console.log(data);
   this.placingService.update(data).subscribe(data=>(this.placingorder=data));
   this.placingorder.id=data.id;
   alert("Orderded placed successfully");
  }
}