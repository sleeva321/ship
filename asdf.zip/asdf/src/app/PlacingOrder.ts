export class PlacingOrder{
    id:number;
    address:string;
    city:string;
    zipcode:number;
    price:number;
    dod:string;
    }